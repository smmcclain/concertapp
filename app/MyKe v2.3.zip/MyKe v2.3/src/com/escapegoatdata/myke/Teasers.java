package com.escapegoatdata.myke;

public class Teasers {
	
	public static void load() {
		Data.teasers[0] = "Fonzie's Been Cloned!";
		Data.teasers[1] = "Bart Simpson Wins Senate Race!";
		Data.teasers[2] = "You Look Fabulous!";
		Data.teasers[3] = "The Zombie Apocolypse has Begun!";
		Data.teasers[4] = "Les Mis is Touring Again!";
		Data.teasers[5] = "Steven Colbert will Host the Oscars!";
		Data.teasers[6] = "Lost Frank Sinatra Recordings Discovered!";
		Data.teasers[7] = "Bjork and Pink Get Married!";
		Data.teasers[8] = "Springsteen Visits the Queen";
		Data.teasers[9] = "Elvis Spotted in Colorado!";
		
	}

}
